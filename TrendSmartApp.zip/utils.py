import yfinance as yf

def fetch_stock_data(ticker):
    try:
        data = yf.download(ticker, period="1mo", interval="1d")
        return data
    except Exception as e:
        return {}

def get_summary_from_chatgpt(ticker, data):
    return f"AI Summary for {ticker}: Trend appears bullish based on recent momentum and volume."

def get_top_movers():
    return [("AAPL", 2.35), ("NVDA", 4.21), ("TSLA", -1.12), ("MSFT", 1.67), ("AMZN", 3.14)]