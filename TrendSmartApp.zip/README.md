# TrendSmart AI

An AI-powered stock trend app that shows you what to invest in, featuring:
- Trending stocks
- 1-click AI summaries
- Watchlist (Premium)
- Substack email alerts

Deploy on Streamlit: https://streamlit.io/cloud